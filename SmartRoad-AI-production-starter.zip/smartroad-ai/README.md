# SmartRoad AI
**Intelligent Road Health, Mobility & Emergency Response Network**

Production-oriented monorepo for Indian smart-city mobility.

## Architecture
```text
Next.js 15 + TypeScript + Tailwind + Leaflet
                    |
                 REST API
                    |
FastAPI (Clean Architecture / Domain Services)
       |              |                |
 PostgreSQL       Redis (optional)   AI Service
                                    YOLOv8 / RF / XGBoost
                    |
                  Azure
```

## Quick start
```bash
cp .env.example .env
docker compose up --build
```

- Frontend: http://localhost:3000
- API docs: http://localhost:8000/docs

## Main modules
- Road Health Intelligence: pothole reports + sensor scoring
- Flood Risk Prediction: weather/flood feature scoring
- Event Congestion Prediction
- Multi-objective route scoring
- Emergency Green Corridor workflow
- Municipal GIS dashboard
- AI training pipeline

## GitHub
```bash
git init
git add .
git commit -m "feat: initial SmartRoad AI platform"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/smartroad-ai.git
git push -u origin main
```

## Azure deployment
1. Create Azure Container Registry.
2. Push `backend` and `frontend` images.
3. Create PostgreSQL Flexible Server.
4. Deploy containers to Azure Container Apps.
5. Store `DATABASE_URL`, JWT secrets and API keys in Key Vault / Container Apps secrets.
6. Put frontend behind Azure Front Door.
7. Add Application Insights and Managed Identity.

## Security
- Passwords hashed with bcrypt.
- JWT authentication with role claims.
- Parameterized ORM queries.
- CORS allowlist.
- Upload size/type validation.
- Never commit secrets.
- Use Azure Managed Identity and Key Vault in production.
- Add WAF, rate limiting, audit logging and database backups.
