from pydantic import BaseModel, Field
class Point(BaseModel): lat: float; lng: float
class RoadReportIn(BaseModel):
    report_type: str = Field(pattern="^(pothole|damage|flood)$")
    severity: float = Field(ge=0, le=1)
    lat: float; lng: float
    sensor: dict|None = None
class RouteRequest(BaseModel):
    origin: Point; destination: Point
    traffic: float=Field(0,ge=0,le=1)
    road_health: float=Field(1,ge=0,le=1)
    flood_risk: float=Field(0,ge=0,le=1)
    carbon: float=Field(0,ge=0,le=1)
class EmergencyRequest(BaseModel):
    vehicle_type: str
    origin: Point; destination: Point
