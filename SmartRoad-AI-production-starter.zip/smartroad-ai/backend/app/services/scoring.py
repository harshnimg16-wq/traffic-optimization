def road_health_score(pothole_probability: float, vibration: float, reports: int) -> float:
    penalty = pothole_probability*45 + min(vibration/20,1)*30 + min(reports/10,1)*25
    return round(max(0,100-penalty),2)
def flood_risk(rain_mm: float, water_level: float, drainage: float) -> float:
    return round(min(1.0, 0.45*min(rain_mm/100,1)+0.4*water_level+0.15*(1-drainage)),3)
def route_score(traffic, road_health, flood_risk, carbon):
    return round(0.35*traffic + 0.30*(1-road_health) + 0.25*flood_risk + 0.10*carbon, 4)
