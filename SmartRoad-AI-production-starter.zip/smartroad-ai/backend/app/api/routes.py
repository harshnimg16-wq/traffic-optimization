from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db import get_session
from app.models import RoadReport, EmergencySession
from app.schemas import RoadReportIn, RouteRequest, EmergencyRequest
from app.services.scoring import route_score
router=APIRouter()
@router.get("/health")
async def health(): return {"status":"ok"}
@router.post("/road-reports")
async def create_report(payload:RoadReportIn, session:AsyncSession=Depends(get_session)):
    row=RoadReport(**payload.model_dump()); session.add(row); await session.commit(); await session.refresh(row)
    return {"id":str(row.id),"message":"Road report accepted"}
@router.post("/routes/score")
async def score_route(p:RouteRequest):
    return {"risk_score":route_score(p.traffic,p.road_health,p.flood_risk,p.carbon),
            "recommendation":"GREEN" if route_score(p.traffic,p.road_health,p.flood_risk,p.carbon)<.35 else "CAUTION"}
@router.post("/emergency/activate")
async def emergency(p:EmergencyRequest, session:AsyncSession=Depends(get_session)):
    row=EmergencySession(vehicle_type=p.vehicle_type,origin=p.origin.model_dump(),destination=p.destination.model_dump())
    session.add(row); await session.commit(); await session.refresh(row)
    return {"session_id":str(row.id),"status":"ACTIVE","signal_recommendation":"PRIORITIZE_CORRIDOR","citizen_alert_radius_m":1000}
@router.get("/dashboard/summary")
async def summary():
    return {"pothole_clusters":12,"flood_zones":4,"traffic_hotspots":9,"active_emergencies":1}
