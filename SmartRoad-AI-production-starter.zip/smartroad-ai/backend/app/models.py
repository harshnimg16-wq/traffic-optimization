import uuid
from datetime import datetime
from sqlalchemy import String, Float, DateTime, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column
from app.db import Base
class RoadReport(Base):
    __tablename__="road_reports"
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    reporter_id: Mapped[str|None]=mapped_column(String(64), nullable=True)
    report_type: Mapped[str]=mapped_column(String(32))
    severity: Mapped[float]=mapped_column(Float)
    lat: Mapped[float]=mapped_column(Float)
    lng: Mapped[float]=mapped_column(Float)
    sensor: Mapped[dict|None]=mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
class EmergencySession(Base):
    __tablename__="emergency_sessions"
    id: Mapped[uuid.UUID]=mapped_column(primary_key=True, default=uuid.uuid4)
    vehicle_type: Mapped[str]=mapped_column(String(32))
    origin: Mapped[dict]=mapped_column(JSON)
    destination: Mapped[dict]=mapped_column(JSON)
    status: Mapped[str]=mapped_column(String(24), default="ACTIVE")
