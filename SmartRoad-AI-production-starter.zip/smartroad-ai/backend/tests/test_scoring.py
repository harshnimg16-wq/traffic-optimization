from app.services.scoring import road_health_score, flood_risk, route_score
def test_road_score(): assert road_health_score(1,20,10)==0
def test_flood_range(): assert 0 <= flood_risk(100,1,.5) <= 1
def test_route(): assert route_score(.1,.9,.1,.1) < .2
