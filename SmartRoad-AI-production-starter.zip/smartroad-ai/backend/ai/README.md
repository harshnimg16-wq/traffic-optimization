# AI pipeline
1. Label potholes for YOLOv8 (`images/train`, `images/val`, YAML config).
2. Train: `yolo detect train data=data.yaml model=yolov8n.pt epochs=100`.
3. Export ONNX/TensorRT for Azure inference.
4. Train RF/XGBoost with `python train.py data.csv --out artifacts`.
5. Register/version models in Azure ML for production.
