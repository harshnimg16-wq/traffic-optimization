import argparse, pandas as pd, joblib
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
def train(csv,out):
    df=pd.read_csv(csv); X=df.drop(columns=["target"]); y=df["target"]
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42)
    models={"random_forest":RandomForestRegressor(n_estimators=200,random_state=42),
            "xgboost":XGBRegressor(n_estimators=250,max_depth=6,learning_rate=.05)}
    scores={}
    for name,m in models.items():
        m.fit(Xtr,ytr); joblib.dump(m,f"{out}/{name}.joblib"); scores[name]=m.score(Xte,yte)
    print(scores)
if __name__=="__main__":
    p=argparse.ArgumentParser(); p.add_argument("csv"); p.add_argument("--out",default="artifacts"); a=p.parse_args()
    train(a.csv,a.out)
