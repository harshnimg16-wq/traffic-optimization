# API endpoints
- `GET /api/v1/health`
- `POST /api/v1/road-reports`
- `POST /api/v1/routes/score`
- `POST /api/v1/emergency/activate`
- `GET /api/v1/dashboard/summary`

Production expansion: `/auth/*`, `/roads/*`, `/flood/*`, `/events/*`, `/signals/*`, `/alerts/*`, `/models/*`, `/webhooks/weather`.
