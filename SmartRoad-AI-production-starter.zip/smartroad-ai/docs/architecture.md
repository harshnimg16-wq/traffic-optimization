# System Architecture

## Clean architecture
`api -> application services -> domain models -> repositories -> infrastructure`

## Event flow
Smartphone/camera -> report API -> validation -> PostgreSQL/PostGIS-ready geometry -> AI scoring -> municipality dashboard.

Emergency flow: emergency activation -> route candidate scoring -> corridor state -> signal recommendations -> citizen proximity alerts.

## ER diagram
```mermaid
erDiagram
  USERS ||--o{ ROAD_REPORTS : submits
  USERS ||--o{ EMERGENCY_SESSIONS : activates
  ROAD_REPORTS ||--o{ ROAD_HEALTH_SCORES : produces
  ROAD_SEGMENTS ||--o{ ROAD_HEALTH_SCORES : has
  ROAD_SEGMENTS ||--o{ FLOOD_PREDICTIONS : has
  ROAD_SEGMENTS ||--o{ CONGESTION_PREDICTIONS : has
  EMERGENCY_SESSIONS ||--o{ EMERGENCY_ALERTS : emits
  EVENTS ||--o{ CONGESTION_PREDICTIONS : influences
  USERS { uuid id PK string email string role }
  ROAD_SEGMENTS { uuid id string name float lat float lng }
  ROAD_REPORTS { uuid id uuid reporter_id string type float severity }
  ROAD_HEALTH_SCORES { uuid id uuid segment_id float score }
  FLOOD_PREDICTIONS { uuid id uuid segment_id float risk }
  EVENTS { uuid id string name float lat float lng datetime starts_at }
  CONGESTION_PREDICTIONS { uuid id uuid segment_id float level }
  EMERGENCY_SESSIONS { uuid id uuid user_id string vehicle_type string status }
```
