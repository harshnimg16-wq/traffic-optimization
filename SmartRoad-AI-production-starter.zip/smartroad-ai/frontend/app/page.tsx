"use client";
import {useState} from "react";
const API=process.env.NEXT_PUBLIC_API_URL||"http://localhost:8000/api/v1";
export default function Home(){
 const [data,setData]=useState<any>(null); const [loading,setLoading]=useState(false);
 async function emergency(){setLoading(true); const r=await fetch(API+"/emergency/activate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({vehicle_type:"ambulance",origin:{lat:11.0168,lng:76.9558},destination:{lat:11.026,lng:76.99}})});setData(await r.json());setLoading(false)}
 async function report(){setLoading(true); const r=await fetch(API+"/road-reports",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({report_type:"pothole",severity:.8,lat:11.0168,lng:76.9558,sensor:{accelerometer_peak:17}})});setData(await r.json());setLoading(false)}
 return <main className="min-h-screen p-6 md:p-10 max-w-7xl mx-auto">
  <header className="mb-8"><div className="text-cyan-400 text-sm tracking-widest">SMART CITY AI PLATFORM</div><h1 className="text-4xl md:text-6xl font-bold mt-2">SmartRoad AI</h1><p className="text-slate-400 mt-3">Intelligent Road Health, Mobility & Emergency Response Network</p></header>
  <section className="grid md:grid-cols-4 gap-4 mb-6">{[["Road Health","82/100","Healthy network"],["Flood Risk","0.28","Low–Moderate"],["Hotspots","9","Congestion clusters"],["Emergencies","1","Active corridor"]].map(x=><div className="card" key={x[0]}><div className="text-slate-400">{x[0]}</div><div className="text-3xl font-bold text-cyan-300 my-2">{x[1]}</div><small>{x[2]}</small></div>)}</section>
  <section className="grid lg:grid-cols-3 gap-6">
   <div className="card lg:col-span-2"><h2 className="text-2xl font-semibold mb-4">GIS Mobility Command Map</h2><div className="h-[380px] rounded-xl bg-gradient-to-br from-slate-800 to-slate-950 border border-slate-700 flex items-center justify-center text-center text-slate-400">Leaflet map layer placeholder<br/>Road health • flood zones • events • emergency corridors</div></div>
   <div className="card"><h2 className="text-xl font-semibold">Command Actions</h2><div className="space-y-3 mt-4"><button onClick={report} className="w-full bg-amber-500 text-black rounded-xl p-3 font-semibold">Report Pothole</button><button onClick={emergency} className="w-full bg-red-500 rounded-xl p-3 font-semibold">Activate Emergency Corridor</button><button className="w-full bg-cyan-600 rounded-xl p-3">Optimize Smart Route</button></div>{loading&&<p className="mt-4">Processing…</p>}{data&&<pre className="mt-4 p-3 rounded bg-black/30 text-xs overflow-auto">{JSON.stringify(data,null,2)}</pre>}</div>
  </section>
  <section className="grid md:grid-cols-3 gap-6 mt-6"><div className="card"><h3>Road Health Intelligence</h3><p className="text-slate-400">Camera + accelerometer + reports → YOLO-assisted pothole evidence and health score.</p></div><div className="card"><h3>Flood AI</h3><p className="text-slate-400">Rainfall, drainage and water-level features generate road-level risk.</p></div><div className="card"><h3>Municipal Governance</h3><p className="text-slate-400">Prioritize repair clusters, flood zones and mobility hotspots.</p></div></section>
 </main>
}
